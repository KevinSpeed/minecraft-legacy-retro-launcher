import html
import os
from pathlib import Path
import random
import sys
import threading

from PySide6.QtCore import Qt, QThread, Signal, QTimer, QUrl
from PySide6.QtGui import QColor, QPainter, QPixmap, QBrush, QPalette, QDesktopServices, QFont, QIcon, QLinearGradient, QRegion, QBitmap
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QCheckBox, QProgressBar, QTextBrowser, QDialog, QFormLayout,
    QLineEdit, QSpinBox, QDialogButtonBox, QFileDialog, QMessageBox, QFrame)
import core
from news import NewsPanel

def texture(brown=False):
    if brown:
        original = QPixmap(str(Path(__file__).resolve().parent / 'assets' / 'dirt.png'))
        if not original.isNull():
            return original.scaled(64, 64, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.FastTransformation)
    pixmap = QPixmap(96, 96)
    painter = QPainter(pixmap)
    rng = random.Random(91 if brown else 14)
    for y in range(0, 96, 3):
        for x in range(0, 96, 3):
            n = rng.randrange(-7, 8)
            base = (38, 28, 19) if brown else (27, 27, 27)
            painter.fillRect(x, y, 3, 3, QColor(*[max(0, c+n) for c in base]))
    painter.end()
    return pixmap

def textured(widget, brown=False):
    palette = widget.palette()
    palette.setBrush(QPalette.ColorRole.Window, QBrush(texture(brown)))
    widget.setPalette(palette)
    widget.setAutoFillBackground(True)

class LegacyBar(QWidget):
    def __init__(self):
        super().__init__()
        self.tile = texture(True)
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawTiledPixmap(self.rect(), self.tile)
        shadow = QLinearGradient(0, 0, 0, self.height())
        shadow.setColorAt(0, QColor(0, 0, 0, 0))
        shadow.setColorAt(1, QColor(0, 0, 0, 96))
        painter.fillRect(self.rect(), shadow)
        highlight = QLinearGradient(0, 0, 0, 2)
        highlight.setColorAt(0, QColor(255, 255, 255, 32))
        highlight.setColorAt(1, QColor(255, 255, 255, 0))
        painter.fillRect(0, 0, self.width(), 2, highlight)

class Job(QThread):
    done = Signal(object)
    failed = Signal(str)
    status = Signal(str)
    progress = Signal(int)
    maximum = Signal(int)
    def __init__(self, task, parent):
        super().__init__(parent)
        self.task = task
        self.cancel = threading.Event()
    def run(self):
        try:
            self.done.emit(self.task(self))
        except Exception as error:
            self.failed.emit(core.friendly_error(error))

class Options(QDialog):
    def __init__(self, config, parent):
        super().__init__(parent)
        self.setWindowTitle('Launcher-Optionen')
        self.setMinimumWidth(610)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.manifest = parent.manifest
        self.install_requested = False
        self.versions = QComboBox()
        self.versions.setMinimumWidth(240)
        form.addRow('Minecraft-Version:', self.versions)
        self.snapshots = QCheckBox('Snapshots anzeigen')
        self.snapshots.setChecked(config['snapshots'])
        self.old_versions = QCheckBox('Old Versions anzeigen (Alpha / Beta / Classic)')
        self.old_versions.setChecked(config.get('old_versions', False))
        form.addRow('', self.snapshots); form.addRow('', self.old_versions)
        self.preferred_version = config['version']
        self.snapshots.toggled.connect(self.filter_versions)
        self.old_versions.toggled.connect(self.filter_versions)
        self.filter_versions()
        self.remember = QCheckBox('Angemeldet bleiben')
        self.remember.setChecked(config['remember'])
        form.addRow('Anmeldung:', self.remember)
        self.directory = QLineEdit(config['directory'])
        choose = QPushButton('Durchsuchen …')
        choose.clicked.connect(self.choose_directory)
        row = QHBoxLayout(); row.addWidget(self.directory); row.addWidget(choose)
        form.addRow('Spielverzeichnis:', row)
        self.java = QLineEdit(config['java'])
        self.java.setPlaceholderText('Automatisch aus den Mojang-Versionsdaten')
        choose_java = QPushButton('Durchsuchen …')
        choose_java.clicked.connect(self.choose_java)
        row = QHBoxLayout(); row.addWidget(self.java); row.addWidget(choose_java)
        form.addRow('Java (optional):', row)
        self.ram = QSpinBox(); self.ram.setRange(1, 64); self.ram.setSuffix(' GB'); self.ram.setValue(config['ram'])
        form.addRow('Maximaler Arbeitsspeicher:', self.ram)
        layout.addLayout(form)
        note = QLabel('Vanilla Java Edition · Windows 10/11 (64 Bit)\nSpielstände liegen im gewählten Spielverzeichnis. Für ältere Versionen ist ein separates Verzeichnis sinnvoll.')
        note.setWordWrap(True); layout.addWidget(note)
        install = QPushButton('Ausgewählte Version installieren')
        install.clicked.connect(self.request_install)
        layout.addWidget(install)
        licenses = QPushButton('Lizenzen')
        licenses.clicked.connect(self.show_licenses)
        layout.addWidget(licenses)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.validate); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    def show_licenses(self):
        folder = Path(__file__).resolve().parent
        license_folder = folder / 'licenses'
        if not license_folder.exists():
            license_folder = folder.parent / 'licenses'
        parts = ['RetroCraft verwendet unveränderte Open-Source-Bibliotheken und Microsoft WebView2.\n'
                 'Qt / PySide6: https://code.qt.io/cgit/pyside/pyside-setup.git/\n'
                 'Qt-Bibliotheken: https://download.qt.io/official_releases/qt/\n'
                 'Die dynamischen Qt-Bibliotheken können durch kompatible Builds ersetzt werden.\n'
                 'Reverse Engineering zur Fehlersuche an Änderungen der LGPL-Komponenten ist erlaubt.']
        for file in sorted(license_folder.rglob('*')):
            if file.is_file() and 'QtWebEngine' not in file.parts:
                parts.append(str(file.relative_to(license_folder)) + '\n\n' + file.read_text(encoding='utf-8', errors='replace'))
        sdk_license = folder / 'browser/bin/WebView2-LICENSE.txt'
        if sdk_license.is_file():
            parts.append('Microsoft WebView2 SDK\n\n' + sdk_license.read_text(encoding='utf-8'))
        dialog = QDialog(self)
        dialog.setWindowTitle('Lizenzen')
        dialog.resize(760, 520)
        layout = QVBoxLayout(dialog)
        text = QTextBrowser()
        text.setPlainText('\n\n' + ('\n\n' + '=' * 70 + '\n\n').join(parts))
        layout.addWidget(text)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(dialog.reject)
        layout.addWidget(close)
        dialog.exec()
    def filter_versions(self):
        previous = self.versions.currentData() or self.preferred_version
        self.versions.clear()
        for entry in available_versions(self.manifest, self.snapshots.isChecked(), self.old_versions.isChecked()):
            kind = {'old_alpha': 'Alpha / Classic', 'old_beta': 'Beta', 'snapshot': 'Snapshot'}.get(entry['type'])
            self.versions.addItem(entry['id'] + (f'  ({kind})' if kind else ''), entry['id'])
        index = self.versions.findData(previous)
        if index >= 0: self.versions.setCurrentIndex(index)
    def request_install(self):
        if not self.versions.currentData():
            QMessageBox.information(self, 'Versionen', 'Keine Versionsliste verfügbar. Bitte den Launcher mit Internetverbindung erneut öffnen.'); return
        self.install_requested = True
        self.validate()
        if self.result() != QDialog.DialogCode.Accepted: self.install_requested = False
    def choose_directory(self):
        value = QFileDialog.getExistingDirectory(self, 'Spielverzeichnis', self.directory.text())
        if value: self.directory.setText(value)
    def choose_java(self):
        value, _ = QFileDialog.getOpenFileName(self, 'Java auswählen', '', 'Java (java.exe javaw.exe)')
        if value: self.java.setText(value)
    def validate(self):
        if not self.directory.text().strip() or not Path(self.directory.text()).is_absolute():
            QMessageBox.warning(self, 'Verzeichnis', 'Bitte ein absolutes Spielverzeichnis auswählen.'); return
        if self.java.text().strip() and not Path(self.java.text()).is_file():
            QMessageBox.warning(self, 'Java', 'Die ausgewählte Java-Datei existiert nicht.'); return
        self.accept()

def available_versions(manifest, snapshots=False, old_versions=False):
    types = {'release'}
    if snapshots: types.add('snapshot')
    if old_versions: types.update(('old_alpha', 'old_beta'))
    return [entry for entry in manifest.get('versions', []) if entry['type'] in types]

class Launcher(QMainWindow):
    def __init__(self, preview=False):
        super().__init__()
        self.preview = preview
        self.config = core.settings()
        self.account = None
        self.manifest = core.read_json(core.ROOT / 'versions.json', {'versions': []})
        self.job = None
        self.jobs = set()
        self.game = None
        self.setWindowTitle('Minecraft Retro Launcher')
        self.resize(1180, 740); self.setMinimumSize(920, 580)
        self.setWindowIcon(QIcon(str(Path(__file__).resolve().parent / 'assets' / 'grass-block.png')))
        root = QWidget(); self.setCentralWidget(root)
        outer = QVBoxLayout(root); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        top = QWidget(); textured(top)
        columns = QVBoxLayout(top); columns.setContentsMargins(0, 0, 0, 0)
        self.news = NewsPanel(top, load=not preview or '--live-news' in sys.argv)
        columns.addWidget(self.news)
        outer.addWidget(top, 1)
        bar = LegacyBar()
        bar.setFixedHeight(102)
        bottom = QHBoxLayout(bar); bottom.setContentsMargins(24, 14, 18, 12); bottom.setSpacing(24)
        logo = QLabel()
        self.logo = logo
        logo_path = Path(__file__).resolve().parent / 'assets' / 'retrocraft-logo.png'
        logo_image = QPixmap(str(logo_path))
        if not logo_image.isNull():
            # Fit the visible wordmark, excluding transparent canvas margins.
            mask = logo_image.toImage().createAlphaMask(Qt.ImageConversionFlag.ThresholdDither)
            bounds = QRegion(QBitmap.fromImage(mask)).boundingRect()
            if not bounds.isEmpty():
                logo_image = logo_image.copy(bounds)
            logo.setPixmap(logo_image.scaled(256, 49, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        logo.setFixedSize(256, 49)
        logo.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        logo.setToolTip('RetroCraft')
        logo.setAccessibleName('RetroCraft')
        brand = QVBoxLayout(); brand.addStretch(); brand.addWidget(logo)
        legal = QLabel('Independent fan project.\nNOT AN OFFICIAL MINECRAFT PRODUCT.\nNot approved by or affiliated with Mojang or Microsoft.')
        legal.setWordWrap(True)
        legal.setStyleSheet('color:#9c9388;font-size:8px;')
        legal.setToolTip('This launcher is independent and is not approved by or affiliated with Mojang or Microsoft.')
        brand.addWidget(legal); brand.addStretch()
        bottom.addLayout(brand)
        controls = QVBoxLayout()
        self.selection = QLabel(); self.selection.setStyleSheet('color:#d6caba;font-size:11px')
        controls.addWidget(self.selection)
        self.status = QLabel('Bereit. Melde dich mit deinem Microsoft-Konto an.'); self.status.setStyleSheet('color:#d6caba;font-size:11px'); self.status.setWordWrap(True); controls.addWidget(self.status)
        self.progress = QProgressBar(); self.progress.setMaximumHeight(9); self.progress.setTextVisible(False); self.progress.setValue(0); controls.addWidget(self.progress)
        bottom.addLayout(controls, 1)
        right = QVBoxLayout()
        row = QHBoxLayout(); self.user = QLabel('Nicht angemeldet'); self.user.setStyleSheet('color:white;font-size:12px'); row.addWidget(self.user, 1)
        self.options = QPushButton('Optionen'); self.options.clicked.connect(self.show_options); row.addWidget(self.options); right.addLayout(row)
        row = QHBoxLayout(); self.login_button = QPushButton('Microsoft-Login'); self.login_button.clicked.connect(self.sign_in); row.addWidget(self.login_button)
        self.play = QPushButton('Spielen'); self.play.setMinimumWidth(100); self.play.clicked.connect(self.start_game); row.addWidget(self.play); right.addLayout(row)
        bottom.addLayout(right)
        outer.addWidget(bar)
        self.timer = QTimer(self); self.timer.timeout.connect(self.watch_game); self.timer.start(1500)
        self.filter_versions()
        if not preview: QTimer.singleShot(100, self.load_versions)

    def persist(self):
        if self.preview: return
        core.write_json(core.ROOT / 'settings.json', self.config)

    def filter_versions(self):
        entries = available_versions(self.manifest, self.config['snapshots'], self.config.get('old_versions', False))
        if entries and self.config['version'] not in {entry['id'] for entry in entries}:
            self.config['version'] = entries[0]['id']
        self.selection.setText('Minecraft ' + self.config['version'] if self.config['version'] else 'Version unter Optionen auswählen')

    def run_job(self, task, done, login=False):
        if self.job: return
        self.set_busy(True, login)
        job = Job(task, self); self.job = job; self.jobs.add(job)
        job.status.connect(self.status.setText); job.maximum.connect(self.progress.setMaximum); job.progress.connect(self.progress.setValue)
        job.done.connect(done); job.failed.connect(self.show_error)
        job.finished.connect(lambda: self.finish_job(job))
        job.start()

    def set_busy(self, busy, login=False):
        for widget in [self.options, self.play]:
            widget.setEnabled(not busy)
        self.login_button.setEnabled(not busy or login)
        self.login_button.setText('Abbrechen' if busy and login else ('Abmelden' if self.account else 'Microsoft-Login'))
        if busy: self.progress.setRange(0, 0)

    def finish_job(self, job):
        self.jobs.discard(job)
        if self.job is job:
            self.job = None; self.set_busy(False); self.progress.setRange(0, 100); self.progress.setValue(0)
        job.deleteLater()
        if getattr(self, 'restore_pending', False):
            self.restore_pending = False; QTimer.singleShot(0, self.restore_account)

    def show_error(self, text):
        self.status.setText(text); QMessageBox.warning(self, 'Retro Launcher', text)

    def load_versions(self):
        self.status.setText('Offizielle Versionsliste wird geladen …')
        self.run_job(lambda job: core.version_list(), self.versions_loaded)

    def versions_loaded(self, data):
        self.manifest = data; self.filter_versions()
        self.status.setText(f"{len(data['versions'])} Versionen gefunden. Bereit.")
        if not getattr(self, 'restored', False): self.restore_pending = True

    def restore_account(self):
        self.restored = True
        try: saved = core.load_account()
        except Exception as error: self.show_error(core.friendly_error(error)); return
        if saved and saved['client_id'] == core.MICROSOFT_CLIENT_ID:
            self.status.setText('Gespeicherte Anmeldung wird erneuert …')
            self.run_job(lambda job: core.refresh(core.MICROSOFT_CLIENT_ID, saved['refresh_token']), self.signed_in)

    def signed_in(self, account):
        self.account = account; self.user.setText(account['name'])
        self.status.setText('Angemeldet. Wähle eine Version und klicke auf Spielen.')
        try: core.save_account(account, core.MICROSOFT_CLIENT_ID, self.config['remember'])
        except Exception:
            self.config['remember'] = False
            core.forget_account()
            self.persist()
            self.show_error('Die Sitzung konnte nicht sicher gespeichert werden. Du bist für dieses Fenster angemeldet; „Angemeldet bleiben“ wurde deaktiviert.')

    def sign_in(self):
        if self.job:
            self.job.cancel.set(); self.status.setText('Anmeldung wird abgebrochen …'); return
        if self.account:
            core.forget_account(); self.account = None; self.user.setText('Nicht angemeldet'); self.login_button.setText('Microsoft-Login'); self.status.setText('Abgemeldet.'); return
        self.persist()
        self.run_job(lambda job: core.login(core.MICROSOFT_CLIENT_ID, job.cancel, job.status.emit), self.signed_in, login=True)

    def remember_changed(self):
        try:
            if self.account: core.save_account(self.account, core.MICROSOFT_CLIENT_ID, self.config['remember'])
            elif not self.config['remember']: core.forget_account()
            self.persist()
        except Exception as error: self.show_error(core.friendly_error(error))

    def show_options(self):
        if self.game and self.game.poll() is None:
            self.show_error('Bitte Minecraft vor dem Ändern der Einstellungen beenden.'); return
        dialog = Options(self.config, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.config.update(directory=dialog.directory.text().strip(), java=dialog.java.text().strip(), ram=dialog.ram.value())
            self.config.update(version=dialog.versions.currentData() or self.config['version'], snapshots=dialog.snapshots.isChecked(), old_versions=dialog.old_versions.isChecked(), remember=dialog.remember.isChecked())
            self.filter_versions(); self.remember_changed()
            if dialog.install_requested: self.download_game()

    def download_game(self):
        if self.game and self.game.poll() is None:
            self.show_error('Bitte Minecraft vor einer Installation beenden.'); return
        version = self.config['version']
        if not version: self.show_error('Bitte zuerst die Versionsliste laden.'); return
        self.persist(); config = self.config.copy()
        self.run_job(lambda job: core.install(version, config, job.status.emit, job.progress.emit, job.maximum.emit), lambda _: self.status.setText(f'{version} ist installiert.'))

    def start_game(self):
        if self.game and self.game.poll() is None: self.show_error('Minecraft läuft bereits.'); return
        if not self.account: self.sign_in(); return
        version = self.config['version']
        if not version: self.show_error('Bitte zuerst die Versionsliste laden.'); return
        self.persist(); config = self.config.copy(); token = self.account['refresh_token']
        def work(job):
            job.status.emit('Anmeldung wird geprüft …')
            account = core.refresh(core.MICROSOFT_CLIENT_ID, token)
            try:
                core.save_account(account, core.MICROSOFT_CLIENT_ID, config['remember'])
            except OSError:
                job.status.emit('Sitzung wird nur für dieses Fenster verwendet …')
            core.install(version, config, job.status.emit, job.progress.emit, job.maximum.emit)
            job.status.emit('Minecraft wird gestartet …')
            return account, core.launch(version, config, account)
        def done(result):
            self.account, self.game = result; self.user.setText(self.account['name']); self.status.setText('Minecraft läuft. Viel Spaß!')
        self.run_job(work, done)

    def watch_game(self):
        if self.game and self.game.poll() is not None:
            code = self.game.returncode; self.game = None
            self.status.setText('Minecraft wurde beendet.' if code == 0 else f'Minecraft wurde mit Fehlercode {code} beendet. Details stehen unter logs/latest.log im Spielverzeichnis.')

    def closeEvent(self, event):
        if self.jobs:
            if self.job: self.job.cancel.set()
            self.status.setText('Bitte den laufenden Vorgang abwarten. Eine Browser-Anmeldung wird abgebrochen.')
            event.ignore(); return
        self.persist(); self.news.shutdown(); event.accept()

def main():
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('RetroCraft.Launcher')
    app = QApplication(sys.argv); app.setStyle('Fusion'); app.setFont(QFont('Arial', 10))
    app.setWindowIcon(QIcon(str(Path(__file__).resolve().parent / 'assets' / 'grass-block.png')))
    app.setStyleSheet('QPushButton { padding: 4px 9px; } QComboBox { padding: 3px; } QProgressBar { border:1px solid #555; background:#1a1714; } QProgressBar::chunk { background:#789757; }')
    preview = '--preview' in sys.argv
    window = Launcher(preview)
    window.show()
    if '--screenshot' in sys.argv:
        target = sys.argv[sys.argv.index('--screenshot') + 1]
        def capture(browser_image=None):
            screenshot = window.grab()
            if browser_image is not None:
                painter = QPainter(screenshot)
                area = window.news.view.rect()
                area.moveTopLeft(window.news.view.mapTo(window, area.topLeft()))
                painter.drawPixmap(area, browser_image)
                painter.end()
            saved = screenshot.save(target)
            success = saved and ('--live-news' not in sys.argv or (window.news.last_load_ok is True and browser_image is not None))
            if '--live-news' in sys.argv:
                core.write_json(Path(target).with_suffix('.json'), {'browser': window.news.browser_version, 'loaded': window.news.last_load_ok, 'page': window.news.last_metrics})
            window.close()
            app.exit(0 if success else 1)
        QTimer.singleShot(10000 if '--live-news' in sys.argv else 700, lambda: window.news.capture(capture) if '--live-news' in sys.argv else capture())
    sys.exit(app.exec())

if __name__ == '__main__': main()
