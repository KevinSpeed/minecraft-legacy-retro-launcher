import json
import os
from pathlib import Path
import tempfile
import threading
from urllib.parse import urlparse, parse_qs, urlencode
import unittest
from unittest.mock import patch, Mock
import core

class LauncherTests(unittest.TestCase):
    def test_login_receives_browser_callback_and_uses_pkce(self):
        requests = []
        def browser(url):
            query = parse_qs(urlparse(url).query)
            self.assertEqual(query['client_id'], [core.MICROSOFT_CLIENT_ID])
            state = query['state'][0]
            thread = threading.Thread(target=lambda: requests.append(core.requests.get(core.REDIRECT + '?' + urlencode({'state': state, 'code': 'test-code'})).status_code))
            thread.start()
            return True
        with patch.object(core.webbrowser, 'open', side_effect=browser), patch.object(core.mc.microsoft_account, 'complete_login', return_value={'name': 'Test'}) as complete:
            result = core.login(core.MICROSOFT_CLIENT_ID, threading.Event(), lambda _: None)
            self.assertEqual(result['name'], 'Test')
            self.assertEqual(complete.call_args.args[0], core.MICROSOFT_CLIENT_ID)
            self.assertEqual(complete.call_args.args[3], 'test-code')
            self.assertGreater(len(complete.call_args.args[4]), 30)

    def test_login_cancellation_does_not_exchange_token(self):
        cancelled = threading.Event(); cancelled.set()
        with patch.object(core.webbrowser, 'open', return_value=True), patch.object(core.mc.microsoft_account, 'complete_login') as complete:
            with self.assertRaisesRegex(core.LauncherError, 'abgebrochen'):
                core.login('00000000-0000-0000-0000-000000000001', cancelled, lambda _: None)
            complete.assert_not_called()

    def test_callback_rejects_wrong_state_and_origin(self):
        with self.assertRaises(core.LauncherError):
            core.callback_code(core.REDIRECT + '?code=secret&state=attacker', 'expected')
        with self.assertRaises(core.LauncherError):
            core.callback_code('https://evil.test/callback?code=secret&state=expected', 'expected')
        self.assertEqual(core.callback_code(core.REDIRECT + '?code=ok&state=expected', 'expected'), 'ok')

    def test_callback_denied_or_missing_code(self):
        for query in ['?error=access_denied&state=expected', '?state=expected']:
            with self.assertRaises(core.LauncherError): core.callback_code(core.REDIRECT + query, 'expected')

    def test_dpapi_storage_and_logout(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(core, 'ROOT', Path(directory)):
            account = {'refresh_token': 'test-sensitive-token', 'access_token': 'never-persist'}
            core.save_account(account, 'app-id', True)
            data = (core.ROOT / 'account.bin').read_bytes()
            self.assertNotIn(b'test-sensitive-token', data)
            self.assertNotIn(b'never-persist', data)
            self.assertEqual(core.load_account()['refresh_token'], account['refresh_token'])
            core.save_account(account, 'app-id', False)
            self.assertIsNone(core.load_account())

    def test_error_messages_do_not_leak_tokens(self):
        self.assertNotIn('SECRET', core.friendly_error(ValueError('SECRET')))

    def test_install_callbacks(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(core.mc.install, 'install_minecraft_version') as install:
            callbacks = [Mock(), Mock(), Mock()]
            core.install('1.21', {'directory': directory}, *callbacks)
            args, kwargs = install.call_args
            self.assertEqual(args, ('1.21', directory))
            self.assertEqual(kwargs['callback']['setStatus'], callbacks[0])

    def test_launch_argument_isolation(self):
        with tempfile.TemporaryDirectory() as directory:
            java = Path(directory) / 'javaw.exe'; java.touch()
            config = {'directory': directory, 'ram': 4, 'java': str(java)}
            account = {'name': 'Player', 'id': 'uuid', 'access_token': 'secret'}
            with patch.object(core.mc.command, 'get_minecraft_command', return_value=[str(java), '--accessToken', 'secret']) as build, patch.object(core.subprocess, 'Popen') as process:
                core.launch('1.21', config, account)
                self.assertEqual(build.call_args.args[2]['token'], 'secret')
                self.assertEqual(build.call_args.args[2]['jvmArguments'][0], '-Xmx4G')
                self.assertEqual(process.call_args.args[0], [str(java), '--accessToken', 'secret'])
                self.assertNotIn('shell', process.call_args.kwargs)

    def test_missing_java_is_actionable(self):
        with patch.object(core.mc.command, 'get_minecraft_command', return_value=['nonexistent-java-retro']), patch.object(core.shutil, 'which', return_value=None):
            with self.assertRaisesRegex(core.LauncherError, 'Java'):
                core.launch('1.11', {'directory': '.', 'ram': 2, 'java': ''}, {'name': 'a', 'id': 'b', 'access_token': 'c'})

    def test_atomic_settings_roundtrip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            core.write_json(path, {'directory': 'C:/Spiele/Blöcke'})
            self.assertEqual(core.read_json(path, {}), {'directory': 'C:/Spiele/Blöcke'})
            self.assertFalse(path.with_suffix('.tmp').exists())

    def test_legacy_app_id_is_removed_from_settings(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(core, 'ROOT', Path(directory)):
            path = core.ROOT / 'settings.json'
            for old_id in ('', '00000000-0000-0000-0000-000000000001', core.MICROSOFT_CLIENT_ID):
                core.write_json(path, {'client_id': old_id, 'ram': 8, 'version': 'b1.7.3', 'old_versions': True})
                config = core.settings()
                self.assertNotIn('client_id', config)
                self.assertEqual(config['ram'], 8)
                self.assertEqual(config['version'], 'b1.7.3')
                self.assertTrue(config['old_versions'])
                core.write_json(path, config)
                self.assertNotIn('client_id', core.read_json(path, {}))

if __name__ == '__main__': unittest.main()
