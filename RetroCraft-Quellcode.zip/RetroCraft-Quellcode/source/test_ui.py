import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import unittest
from unittest.mock import patch, Mock
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt, QEvent, QCoreApplication, QUrl
from PySide6.QtTest import QTest
import launcher
import news

if QApplication.instance() is None:
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
app = QApplication.instance() or QApplication([])

class UiTests(unittest.TestCase):
    def test_retrocraft_logo_is_loaded(self):
        self.assertFalse(self.window.logo.pixmap().isNull())
        self.assertLessEqual(self.window.logo.pixmap().width(), 256)
        self.assertLessEqual(self.window.logo.pixmap().height(), 49)
        self.assertEqual(self.window.logo.accessibleName(), 'RetroCraft')

    def test_english_independence_notice_is_visible(self):
        notices = self.window.findChildren(launcher.QLabel)
        text = '\n'.join(label.text() for label in notices)
        self.assertIn('NOT AN OFFICIAL MINECRAFT PRODUCT', text)
        self.assertIn('Mojang or Microsoft', text)

    def test_news_loads_original_website(self):
        with patch.object(self.window.news, 'start_browser') as load:
            self.window.news.reload()
            load.assert_called_once_with()

    def test_news_status_clears_after_success(self):
        self.window.news.loaded(False)
        self.assertFalse(self.window.news.last_load_ok)
        self.assertFalse(self.window.news.message.isHidden())
        self.window.news.loaded(True)
        self.assertTrue(self.window.news.last_load_ok)
        self.assertTrue(self.window.news.message.isHidden())

    def setUp(self):
        self.window = launcher.Launcher(preview=True)
    def tearDown(self):
        self.window.close()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    def test_versions_and_snapshot_filter(self):
        self.window.manifest = {'versions': [{'id': '1.21', 'type': 'release'}, {'id': '24w01a', 'type': 'snapshot'}, {'id': 'b1.7.3', 'type': 'old_beta'}, {'id': 'a1.2.6', 'type': 'old_alpha'}]}
        config = dict(self.window.config, snapshots=False, old_versions=False, version='1.21')
        dialog = launcher.Options(config, self.window)
        self.assertEqual(dialog.versions.count(), 1)
        dialog.snapshots.setChecked(True)
        self.assertEqual(dialog.versions.count(), 2)
        dialog.old_versions.setChecked(True)
        self.assertEqual(dialog.versions.count(), 4)
        dialog.versions.setCurrentIndex(dialog.versions.findData('b1.7.3'))
        dialog.snapshots.setChecked(False)
        self.assertEqual(dialog.versions.currentData(), 'b1.7.3')
        dialog.old_versions.setChecked(False)
        self.assertEqual(dialog.versions.currentData(), '1.21')
        dialog.reject()
        self.assertFalse(self.window.config['old_versions'])

    def test_options_save_selected_old_version(self):
        self.window.manifest = {'versions': [{'id': '1.21', 'type': 'release'}, {'id': 'b1.7.3', 'type': 'old_beta'}]}
        dialog = launcher.Options(self.window.config, self.window)
        option_text = '\n'.join(widget.text() for kind in (launcher.QLabel, launcher.QLineEdit) for widget in dialog.findChildren(kind))
        self.assertNotIn('App-ID', option_text)
        self.assertNotIn(launcher.core.MICROSOFT_CLIENT_ID, option_text)
        self.assertEqual(len(dialog.findChildren(launcher.QLineEdit)), 3)  # Directory, Java, and RAM spin box.
        dialog.old_versions.setChecked(True)
        dialog.versions.setCurrentIndex(dialog.versions.findData('b1.7.3'))
        dialog.remember.setChecked(False)
        with patch.object(launcher, 'Options', return_value=dialog), patch.object(dialog, 'exec', return_value=launcher.QDialog.DialogCode.Accepted), patch.object(launcher.core, 'forget_account'):
            self.window.show_options()
        self.assertTrue(self.window.config['old_versions'])
        self.assertEqual(self.window.config['version'], 'b1.7.3')
        self.assertFalse(self.window.config['remember'])

    def test_login_uses_built_in_app_instead_of_legacy_setting(self):
        self.window.config['client_id'] = 'old-app-id'
        job = Mock()
        with patch.object(self.window, 'run_job') as run, patch.object(launcher.core, 'login') as login:
            self.window.sign_in()
            run.call_args.args[0](job)
            self.assertTrue(run.call_args.kwargs['login'])
            login.assert_called_once_with(launcher.core.MICROSOFT_CLIENT_ID, job.cancel, job.status.emit)

    def test_restore_only_uses_session_for_built_in_app(self):
        saved = {'client_id': launcher.core.MICROSOFT_CLIENT_ID, 'refresh_token': 'test-token'}
        with patch.object(launcher.core, 'load_account', return_value=saved), patch.object(self.window, 'run_job') as run, patch.object(launcher.core, 'refresh') as refresh:
            self.window.restore_account()
            run.call_args.args[0](Mock())
            refresh.assert_called_once_with(launcher.core.MICROSOFT_CLIENT_ID, 'test-token')
            run.reset_mock()
            saved['client_id'] = 'different-app-id'
            self.window.restore_account()
            run.assert_not_called()

    def test_game_refresh_and_storage_use_built_in_app(self):
        self.window.config.update(version='1.21', remember=True, client_id='old-app-id')
        self.window.account = {'refresh_token': 'test-token'}
        renewed = {'name': 'Player', 'refresh_token': 'renewed-token'}
        with patch.object(self.window, 'run_job') as run, patch.object(launcher.core, 'refresh', return_value=renewed) as refresh, patch.object(launcher.core, 'save_account') as save, patch.object(launcher.core, 'install'), patch.object(launcher.core, 'launch'):
            self.window.start_game()
            run.call_args.args[0](Mock())
            refresh.assert_called_once_with(launcher.core.MICROSOFT_CLIENT_ID, 'test-token')
            save.assert_called_once_with(renewed, launcher.core.MICROSOFT_CLIENT_ID, True)
    def test_background_job_finishes_and_unlocks(self):
        received = []
        self.window.run_job(lambda job: 42, received.append)
        for _ in range(100):
            QTest.qWait(10)
            if not self.window.jobs: break
        self.assertEqual(received, [42])
        self.assertIsNone(self.window.job)
        self.assertTrue(self.window.options.isEnabled())
    def test_secure_save_failure_keeps_session_only(self):
        account = {'name': 'Player', 'refresh_token': 'test'}
        self.window.config['remember'] = True
        with patch.object(launcher.core, 'save_account', side_effect=OSError('blocked')), patch.object(launcher.core, 'forget_account'), patch.object(self.window, 'show_error'):
            self.window.signed_in(account)
        self.assertEqual(self.window.account, account)
        self.assertFalse(self.window.config['remember'])

if __name__ == '__main__': unittest.main()
