"""python build.py <extracted Microsoft.Web.WebView2 1.0.4191.47 NuGet SDK>"""
from pathlib import Path
import os
import shutil
import subprocess
import sys

sdk = Path(sys.argv[1]).resolve()
folder = Path(__file__).resolve().parent
output = folder / 'bin'
output.mkdir(exist_ok=True)
compiler = Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
core = sdk / 'lib/net462/Microsoft.Web.WebView2.Core.dll'
subprocess.run([str(compiler), '/nologo', '/target:winexe', '/platform:x64', '/optimize+',
    '/out:' + str(output / 'BrowserHost.exe'), '/reference:System.Windows.Forms.dll',
    '/reference:System.Drawing.dll', '/reference:System.Web.Extensions.dll',
    '/reference:' + str(core), str(folder / 'BrowserHost.cs')], check=True)
shutil.copy2(core, output / core.name)
shutil.copy2(sdk / 'runtimes/win-x64/native/WebView2Loader.dll', output / 'WebView2Loader.dll')
shutil.copy2(sdk / 'LICENSE.txt', output / 'WebView2-LICENSE.txt')
