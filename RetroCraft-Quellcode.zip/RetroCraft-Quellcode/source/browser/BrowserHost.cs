// Small WebView2 host. The website has no host objects or message channel.
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;

internal static class BrowserHost
{
    internal const string Blog = "https://mcretroupdates.tumblr.com/";
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static CoreWebView2Controller Controller;
    static CoreWebView2 Web;
    static Control Dispatcher;
    static Form Surface;
    static System.Windows.Forms.Timer Watch;
    static IntPtr Parent;
    static Process Owner;
    static bool Closing;
    static Rectangle LastBounds;
    static Rectangle LastWindow;

    [StructLayout(LayoutKind.Sequential)]
    struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")] static extern IntPtr SetParent(IntPtr child, IntPtr parent);

    internal static bool IsBlog(string value)
    {
        Uri uri;
        return Uri.TryCreate(value, UriKind.Absolute, out uri) && uri.Scheme == "https"
            && uri.Host == "mcretroupdates.tumblr.com" && uri.Port == 443 && uri.UserInfo == "";
    }

    internal static bool IsWebLink(string value)
    {
        Uri uri;
        return Uri.TryCreate(value, UriKind.Absolute, out uri) && !String.IsNullOrEmpty(uri.Host)
            && (uri.Scheme == "https" || uri.Scheme == "http") && uri.UserInfo == "";
    }

    internal static string NavigationDecision(string url, bool user, bool redirected)
    {
        if (IsBlog(url) || url == "about:blank") return "allow";
        return user && !redirected && IsWebLink(url) ? "external" : "block";
    }

    static void Emit(object message)
    {
        Console.Out.WriteLine(Json.Serialize(message));
        Console.Out.Flush();
    }

    static void External(string value)
    {
        if (IsWebLink(value)) Emit(new { @event = "external", url = value });
    }

    [STAThread]
    static int Main(string[] args)
    {
        if (args.Length == 4 && args[0] == "--navigation-policy")
        {
            Console.WriteLine(NavigationDecision(args[1], args[2] == "true", args[3] == "true"));
            return 0;
        }
        try
        {
            if (args.Length != 3) return 2;
            Parent = new IntPtr(Int64.Parse(args[0]));
            Owner = Process.GetProcessById(Int32.Parse(args[1]));
            if (!IsWindow(Parent) || Owner.HasExited) return 2;
            SetProcessDpiAwarenessContext(new IntPtr(-4));
            Application.EnableVisualStyles();
            Surface = new Form { TopLevel = false, FormBorderStyle = FormBorderStyle.None, ShowInTaskbar = false, BackColor = Color.FromArgb(27, 27, 27) };
            SetParent(Surface.Handle, Parent);
            Surface.Show();
            Dispatcher = Surface;
            SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());
            Watch = new System.Windows.Forms.Timer { Interval = 100 };
            Watch.Tick += delegate { Resize(); };
            Watch.Start();
            Task.Run((Action)ReadCommands);
            Dispatcher.BeginInvoke(new Action(async delegate { await Start(args[2]); }));
            Application.Run();
            return 0;
        }
        catch (Exception error)
        {
            Emit(new { @event = "error", message = error.GetType().Name, code = error.HResult });
            return 1;
        }
        finally
        {
            Closing = true;
            if (Watch != null) Watch.Dispose();
            if (Controller != null) Controller.Close();
            if (Dispatcher != null) Dispatcher.Dispose();
            if (Owner != null) Owner.Dispose();
        }
    }

    static async Task Start(string storage)
    {
        try
        {
            var options = new CoreWebView2EnvironmentOptions();
            options.Language = "de-DE";
            var environment = await CoreWebView2Environment.CreateAsync(null, storage, options);
            if (Closing) return;
            var controller = await environment.CreateCoreWebView2ControllerAsync(Surface.Handle);
            if (Closing) { controller.Close(); return; }
            Controller = controller;
            Controller.DefaultBackgroundColor = Color.FromArgb(27, 27, 27);
            Controller.AllowExternalDrop = false;
            Web = Controller.CoreWebView2;
            Web.Settings.AreHostObjectsAllowed = false;
            Web.Settings.IsScriptEnabled = true;
            Web.Settings.IsWebMessageEnabled = false;
            Web.Settings.AreDevToolsEnabled = false;
            Web.Settings.AreDefaultContextMenusEnabled = false;
            Web.Settings.AreBrowserAcceleratorKeysEnabled = false;
            Web.Settings.IsStatusBarEnabled = false;
            Web.Settings.IsZoomControlEnabled = false;
            Web.Settings.IsPasswordAutosaveEnabled = false;
            Web.Settings.IsGeneralAutofillEnabled = false;
            Web.Settings.IsBuiltInErrorPageEnabled = false;
            Web.PermissionRequested += delegate(object sender, CoreWebView2PermissionRequestedEventArgs e)
            { e.State = CoreWebView2PermissionState.Deny; e.Handled = true; };
            Web.DownloadStarting += delegate(object sender, CoreWebView2DownloadStartingEventArgs e) { e.Cancel = true; };
            Web.LaunchingExternalUriScheme += delegate(object sender, CoreWebView2LaunchingExternalUriSchemeEventArgs e) { e.Cancel = true; };
            Web.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e)
            { e.Handled = true; if (e.IsUserInitiated) External(e.Uri); };
            Web.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
            {
                string decision = NavigationDecision(e.Uri, e.IsUserInitiated, e.IsRedirected);
                if (decision != "allow") { e.Cancel = true; if (decision == "external") External(e.Uri); }
                else Emit(new { @event = "loading" });
            };
            Web.NavigationCompleted += delegate(object sender, CoreWebView2NavigationCompletedEventArgs e)
            {
                if (e.WebErrorStatus != CoreWebView2WebErrorStatus.OperationCanceled)
                    Emit(new { @event = "loaded", success = e.IsSuccess && IsBlog(Web.Source), url = Web.Source, status = e.WebErrorStatus.ToString() });
            };
            Web.ProcessFailed += delegate { Emit(new { @event = "error", message = "BrowserProcessFailed" }); };
            Resize();
            Emit(new { @event = "ready", version = environment.BrowserVersionString });
            Web.Navigate(Blog);
        }
        catch (WebView2RuntimeNotFoundException)
        { Emit(new { @event = "missing-runtime" }); }
        catch (Exception error)
        { Emit(new { @event = "error", message = error.GetType().Name, code = error.HResult }); }
    }

    static void Resize()
    {
        if (Closing) return;
        if (!IsWindow(Parent) || Owner.HasExited) { Close(); return; }
        if (Controller == null) return;
        Rect rect;
        if (GetClientRect(Parent, out rect))
        {
            var bounds = new Rectangle(0, 0, rect.Right - rect.Left, rect.Bottom - rect.Top);
            if (bounds != LastBounds) { Surface.Bounds = bounds; Controller.Bounds = Surface.ClientRectangle; LastBounds = bounds; }
        }
        if (GetWindowRect(Parent, out rect))
        {
            var position = new Rectangle(rect.Left, rect.Top, rect.Right - rect.Left, rect.Bottom - rect.Top);
            if (position != LastWindow) { Controller.NotifyParentWindowPositionChanged(); LastWindow = position; }
        }
        Controller.IsVisible = IsWindowVisible(Parent);
    }

    static void ReadCommands()
    {
        try
        {
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                string command = line;
                if (Closing) return;
                Dispatcher.BeginInvoke(new Action(async delegate { await Command(command); }));
            }
            if (!Closing) Dispatcher.BeginInvoke(new Action(Close));
        }
        catch { if (!Closing) Environment.Exit(1); }
    }

    static async Task Command(string line)
    {
        if (Closing) return;
        try
        {
            var message = Json.Deserialize<System.Collections.Generic.Dictionary<string, object>>(line);
            string command = (string)message["command"];
            if (command == "close") { Close(); return; }
            if (Web == null) return;
            if (command == "reload") Web.Navigate(Blog);
            if (command == "capture")
            {
                string path = (string)message["path"];
                string metrics = await Web.ExecuteScriptAsync("(()=>{try{return {url:location.href,title:document.title,h1:document.querySelector('h1')?.textContent,font:document.body?getComputedStyle(document.body).fontSize:null,width:innerWidth,height:innerHeight,ready:document.readyState}}catch(e){return {error:String(e),url:location.href}}})()");
                using (var file = File.Create(path))
                    await Web.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, file);
                Emit(new { @event = "captured", path = path, metrics = metrics });
            }
        }
        catch (Exception error)
        { Emit(new { @event = "error", message = error.GetType().Name, code = error.HResult }); }
    }

    static void Close() { Closing = true; Application.ExitThread(); }
}
