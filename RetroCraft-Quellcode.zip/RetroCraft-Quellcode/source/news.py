"""Original Tumblr page using the shared Windows WebView2 runtime."""
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import uuid

from PySide6.QtCore import QEventLoop, QTimer, QUrl, Qt
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
import core

NEWS_URL = 'https://mcretroupdates.tumblr.com/'
RUNTIME_URL = 'https://developer.microsoft.com/microsoft-edge/webview2/'


def open_web_link(value):
    url = QUrl(value)
    if url.scheme() in ('https', 'http') and url.host() and not url.userInfo():
        QDesktopServices.openUrl(url)


class NewsPanel(QWidget):
    def __init__(self, parent=None, load=True):
        super().__init__(parent)
        self.last_load_ok = None
        self.browser_version = None
        self.last_metrics = None
        self._closed = False
        self._started = False
        self._messages = queue.Queue(maxsize=256)
        self._reader = None
        self._finished_reported = False
        self._capture = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.message = QLabel('Tumblr-Seite wird geladen …')
        self.message.setStyleSheet('color:#ddd;padding:8px;background:#252525;')
        self.message.setWordWrap(True)
        self.message.linkActivated.connect(lambda _: open_web_link(RUNTIME_URL))
        layout.addWidget(self.message)
        self.view = QWidget(self)
        self.view.setStyleSheet('background:#1b1b1b;')
        layout.addWidget(self.view, 1)
        self.process = None
        self.poll = QTimer(self)
        self.poll.setInterval(25)
        self.poll.timeout.connect(self.read_messages)
        self.capture_timeout = QTimer(self)
        self.capture_timeout.setSingleShot(True)
        self.capture_timeout.timeout.connect(lambda: self.finish_capture(None))
        if load:
            QTimer.singleShot(0, self.reload)
        else:
            self.message.hide()

    def reload(self):
        if self._closed:
            return
        self.loading()
        if not self._started:
            self.start_browser()
        else:
            self.send({'command': 'reload'})

    def start_browser(self):
        helper = Path(__file__).resolve().parent / 'browser' / 'bin' / 'BrowserHost.exe'
        if not helper.is_file():
            self.fail('Die Browser-Komponente fehlt. Bitte den Launcher erneut herunterladen.')
            return
        self.view.setAttribute(Qt.WidgetAttribute.WA_NativeWindow)
        storage = core.ROOT / 'web' / 'webview2'
        storage.mkdir(parents=True, exist_ok=True)
        self._started = True
        self._finished_reported = False
        try:
            # Anonymous synchronous pipes work with .NET's standard streams.
            self.process = subprocess.Popen([str(helper), str(int(self.view.winId())), str(os.getpid()), str(storage)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW)
        except OSError:
            self._started = False
            self.process_error(None)
            return
        self._reader = threading.Thread(target=self.receive_messages, args=(self.process,), daemon=True)
        self._reader.start()
        self.poll.start()

    def send(self, message):
        if self.process is not None and self.process.poll() is None:
            try:
                self.process.stdin.write((json.dumps(message) + '\n').encode('utf-8'))
                self.process.stdin.flush()
            except OSError:
                self.process_error(None)

    def receive_messages(self, process):
        try:
            for line in iter(lambda: process.stdout.readline(1024 * 1024), b''):
                try:
                    message = json.loads(line)
                    if isinstance(message, dict):
                        self._messages.put_nowait(message)
                except (ValueError, TypeError, queue.Full):
                    continue
        finally:
            process.stdout.close()

    def read_messages(self):
        for _ in range(256):
            try:
                self.handle_message(self._messages.get_nowait())
            except queue.Empty:
                break
        if self.process is not None and self.process.poll() is not None and not self._finished_reported:
            self._finished_reported = True
            self.poll.stop()
            self.process_finished()

    def handle_message(self, message):
        if os.environ.get('RETRO_BROWSER_DIAGNOSTICS') == '1':
            print(json.dumps(message), flush=True)
        if self._closed:
            return
        event = message.get('event')
        if event == 'ready':
            self.browser_version = message.get('version')
        elif event == 'loading':
            self.loading()
        elif event == 'loaded':
            self.loaded(message.get('success') is True)
        elif event == 'external':
            open_web_link(message.get('url', ''))
        elif event == 'missing-runtime':
            self.fail('Microsoft WebView2 fehlt. <a style="color:#aaaaff" href="install">Hier einmalig installieren</a> und den Launcher erneut starten.')
        elif event == 'error':
            self.fail('Die Webansicht konnte nicht gestartet werden. Bitte den Launcher erneut öffnen und Microsoft WebView2 prüfen.')
            self.finish_capture(None)
        elif event == 'captured' and self._capture and message.get('path') == str(self._capture[0]):
            pixmap = QPixmap(str(self._capture[0]))
            try:
                self.last_metrics = json.loads(message.get('metrics', '{}'))
            except (ValueError, TypeError):
                self.last_metrics = None
            self.finish_capture(pixmap if not pixmap.isNull() else None)

    def loading(self):
        self.last_load_ok = None
        self.message.setText('Tumblr-Seite wird geladen …')
        self.message.show()

    def loaded(self, success):
        self.last_load_ok = bool(success)
        self.message.setVisible(not success)
        if not success:
            self.message.setText('Tumblr konnte nicht geladen werden. Bitte die Verbindung prüfen und den Launcher erneut starten.')

    def fail(self, text):
        self.last_load_ok = False
        self.message.setText(text)
        self.message.show()

    def process_error(self, error):
        if not self._closed:
            self.fail('Die Webansicht konnte nicht gestartet werden. Bitte den Launcher erneut öffnen.')

    def process_finished(self, *args):
        self._started = False
        if not self._closed:
            self.fail('Die Webansicht wurde beendet. Bitte den Launcher erneut öffnen.')
            self.finish_capture(None)

    def capture(self, callback):
        if self.last_load_ok is not True or self._capture:
            callback(None)
            return
        path = core.ROOT / 'web' / ('preview-' + uuid.uuid4().hex + '.png')
        self._capture = (path, callback)
        self.capture_timeout.start(10000)
        self.send({'command': 'capture', 'path': str(path)})

    def finish_capture(self, pixmap):
        if not self._capture:
            return
        path, callback = self._capture
        self._capture = None
        self.capture_timeout.stop()
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        callback(pixmap)

    def shutdown(self):
        if self._closed:
            return
        self._closed = True
        self.finish_capture(None)
        if self.process is not None and self.process.poll() is None:
            # Keep pumping Windows messages while the child browser destroys its HWNDs.
            loop = QEventLoop(self)
            check = QTimer(self)
            check.timeout.connect(lambda: loop.quit() if self.process.poll() is not None else None)
            check.start(25)
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(lambda: (self.process.kill(), loop.quit()))
            timer.start(3000)
            self.send({'command': 'close'})
            try:
                self.process.stdin.close()
            except OSError:
                pass
            loop.exec()
            timer.stop()
            check.stop()
            check.deleteLater()
            timer.deleteLater()
            loop.deleteLater()
            self.process.wait(timeout=3)
        self.poll.stop()
