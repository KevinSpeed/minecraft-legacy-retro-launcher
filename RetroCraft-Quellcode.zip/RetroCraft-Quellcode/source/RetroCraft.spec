# Build from this file with PyInstaller 6.22.3, Python 3.12 x64.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files

source = Path(SPECPATH)
licenses = source.parent / 'licenses'
datas = [(str(source / 'assets'), 'assets'), (str(source / 'browser' / 'bin'), 'browser/bin')]
datas += collect_data_files('minecraft_launcher_lib')
for folder in licenses.iterdir():
    if folder.is_dir() and folder.name != 'QtWebEngine':
        datas.append((str(folder), 'licenses/' + folder.name))

a = Analysis([str(source / 'launcher.py')], pathex=[str(source)], binaries=[], datas=datas,
    hiddenimports=[], hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=['PySide6.QtWebEngineCore', 'PySide6.QtWebEngineWidgets', 'PySide6.QtQml',
              'PySide6.QtQuick', 'PySide6.QtOpenGL', 'PySide6.QtPdf', 'PySide6.QtTest'],
    noarchive=False, optimize=1)
# This application paints QWidget controls and PNGs, with no Qt OpenGL or PDF view.
a.binaries = [entry for entry in a.binaries if Path(entry[0]).name.lower() not in
    {'opengl32sw.dll', 'qt6pdf.dll', 'qpdf.dll'}]
a.datas = [entry for entry in a.datas if 'PySide6/translations/' not in entry[0].replace('\\', '/')
    or Path(entry[0]).name in ('qtbase_de.qm', 'qtbase_en.qm')]
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name='RetroCraft', debug=False,
    icon=str(source / 'assets' / 'grass-block.ico'),
    bootloader_ignore_signals=False, strip=False, upx=False, console=False,
    disable_windowed_traceback=False, runtime_tmpdir=None)
