"""Minecraft services, isolated from the desktop UI."""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

import requests
import minecraft_launcher_lib as mc

ROOT = Path(os.environ.get('RETRO_LAUNCHER_HOME', str(Path(os.environ.get('APPDATA', str(Path.home()))) / 'RetroMinecraftLauncher')))
MICROSOFT_CLIENT_ID = 'e309d4bd-4b83-4209-85cd-bf44b10cc3e7'
REDIRECT = 'http://localhost:28563/callback'
MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'

# The upstream installer also uses requests; ensure failed connections eventually return.
_request = requests.sessions.Session.request
def _bounded_request(self, method, url, **kwargs):
    kwargs.setdefault('timeout', (15, 60))
    return _request(self, method, url, **kwargs)
requests.sessions.Session.request = _bounded_request

class LauncherError(Exception):
    pass

def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    temporary.replace(path)

def settings():
    defaults = {'ram': 4, 'directory': str(ROOT / 'minecraft'), 'java': '', 'version': '', 'snapshots': False, 'old_versions': False, 'remember': True}
    defaults.update(read_json(ROOT / 'settings.json', {}))
    # Older builds exposed the app ID as a setting; it is now fixed per build.
    defaults.pop('client_id', None)
    return defaults

class Blob(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]

def protect(data, decrypt=False):
    """Windows DPAPI, current Windows user only, no portable plaintext token store."""
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    crypt.CryptProtectData.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    crypt.CryptProtectData.restype = wintypes.BOOL
    crypt.CryptUnprotectData.argtypes = [ctypes.POINTER(Blob), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    crypt.CryptUnprotectData.restype = wintypes.BOOL
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if decrypt:
        ok = crypt.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result))
    else:
        ok = crypt.CryptProtectData(ctypes.byref(source), 'Retro Launcher', None, None, None, 1, ctypes.byref(result))
    if not ok:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        kernel.LocalFree(result.pbData)

def save_account(account, client_id, remember):
    path = ROOT / 'account.bin'
    if not remember:
        path.unlink(missing_ok=True)
        return
    ROOT.mkdir(parents=True, exist_ok=True)
    raw = json.dumps({'refresh_token': account['refresh_token'], 'client_id': client_id}).encode()
    temp = path.with_suffix('.tmp')
    temp.write_bytes(protect(raw))
    temp.replace(path)

def load_account():
    path = ROOT / 'account.bin'
    if not path.exists():
        return None
    try:
        return json.loads(protect(path.read_bytes(), True))
    except Exception:
        raise LauncherError('Gespeicherte Anmeldung konnte nicht gelesen werden. Bitte erneut anmelden.')

def forget_account():
    (ROOT / 'account.bin').unlink(missing_ok=True)

def version_list():
    response = requests.get(MANIFEST)
    response.raise_for_status()
    data = response.json()
    write_json(ROOT / 'versions.json', data)
    return data

def callback_code(url, state):
    parsed = urlparse(url)
    expected = urlparse(REDIRECT)
    query = parse_qs(parsed.query)
    if (parsed.scheme, parsed.netloc, parsed.path) != (expected.scheme, expected.netloc, expected.path):
        raise LauncherError('Unerwartete Anmelde-Rückleitung.')
    if not secrets.compare_digest(query.get('state', [''])[0], state):
        raise LauncherError('Anmeldung konnte nicht sicher zugeordnet werden.')
    if 'error' in query:
        raise LauncherError('Microsoft-Anmeldung wurde abgelehnt oder abgebrochen.')
    code = query.get('code', [''])[0]
    if not code:
        raise LauncherError('Die Anmeldeantwort enthält keinen Code.')
    return code

def login(client_id, cancel, status):
    url, state, verifier = mc.microsoft_account.get_secure_login_data(client_id, REDIRECT)
    result = {}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Never record OAuth codes in request logs.
        def do_GET(self):
            if urlparse(self.path).path != '/callback':
                self.send_error(404)
                return
            try:
                code = callback_code(REDIRECT + '?' + urlparse(self.path).query, state)
            except LauncherError:
                query = parse_qs(urlparse(self.path).query)
                if secrets.compare_digest(query.get('state', [''])[0], state) and 'error' in query:
                    result['error'] = 'Microsoft-Anmeldung wurde abgelehnt oder abgebrochen.'
                self.send_error(400, 'Invalid authentication response')
                return
            result['code'] = code
            body = '<meta charset="utf-8"><h2>Anmeldung empfangen.</h2><p>Du kannst zum Retro Launcher zurückkehren.</p>'.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)
    class LocalServer(HTTPServer):
        def get_request(self):
            connection, address = super().get_request()
            connection.settimeout(2)
            return connection, address
    try:
        server = LocalServer(('127.0.0.1', 28563), Handler)
    except OSError:
        raise LauncherError('Der lokale Anmelde-Port 28563 ist belegt. Schließe andere Launcher-Fenster.')
    server.timeout = 0.4
    try:
        status('Microsoft-Anmeldung im Browser abschließen …')
        if not webbrowser.open(url):
            raise LauncherError('Der Standardbrowser konnte nicht geöffnet werden.')
        deadline = time.monotonic() + 300
        while not result:
            if cancel.is_set():
                raise LauncherError('Anmeldung abgebrochen.')
            if time.monotonic() > deadline:
                raise LauncherError('Anmeldung nach fünf Minuten abgelaufen. Bitte erneut versuchen.')
            server.handle_request()
    finally:
        server.server_close()
    if cancel.is_set():
        raise LauncherError('Anmeldung abgebrochen.')
    if 'error' in result:
        raise LauncherError(result['error'])
    status('Minecraft-Konto wird geprüft …')
    return mc.microsoft_account.complete_login(client_id, None, REDIRECT, result['code'], verifier)

def refresh(client_id, token):
    return mc.microsoft_account.complete_refresh(client_id, None, None, token)

def friendly_error(error):
    if isinstance(error, LauncherError):
        return str(error)
    name = type(error).__name__
    messages = {
        'AzureAppNotPermitted': 'Die Microsoft-App dieses Launchers ist noch nicht für die Minecraft-API freigegeben. Für die Anmeldung muss die Freigabe vorliegen.',
        'AccountNotOwnMinecraft': 'Für dieses Konto wurde keine Minecraft-Java-Lizenz gefunden.',
        'InvalidRefreshToken': 'Deine Sitzung ist abgelaufen. Bitte abmelden und erneut anmelden.',
        'InvalidCredentials': 'Microsoft hat die Anmeldung abgelehnt. Bitte die App-Konfiguration prüfen.',
        'XSTSError': 'Xbox hat die Anmeldung abgelehnt. Prüfe Xbox-Profil und gegebenenfalls Familieneinstellungen.',
    }
    if name in messages:
        return messages[name]
    if isinstance(error, requests.RequestException):
        return 'Der Online-Dienst ist nicht erreichbar oder hat die Anfrage abgelehnt. Prüfe deine Verbindung und versuche es erneut.'
    # Raw upstream errors can include HTTP payloads with credentials.
    return f'Der Vorgang konnte nicht abgeschlossen werden ({name}). Prüfe Einstellungen, Speicherplatz und Verbindung.'

def install(version, config, status, progress, maximum):
    directory = Path(config['directory'])
    directory.mkdir(parents=True, exist_ok=True)
    mc.install.install_minecraft_version(version, str(directory), callback={'setStatus': status, 'setProgress': progress, 'setMax': maximum})

def launch(version, config, account):
    directory = Path(config['directory'])
    options = {'username': account['name'], 'uuid': account['id'], 'token': account['access_token'],
               'jvmArguments': [f"-Xmx{int(config['ram'])}G", '-Xms512M'],
               'launcherName': 'RetroLauncher', 'launcherVersion': '1.0', 'gameDirectory': str(directory)}
    if config['java']:
        options['executablePath'] = config['java']
    command = mc.command.get_minecraft_command(version, str(directory), options)
    if not (Path(command[0]).is_file() or shutil.which(command[0])):
        raise LauncherError('Keine passende Java-Laufzeit gefunden. Bitte unter Optionen eine javaw.exe auswählen; ältere Versionen benötigen meist Java 8.')
    # Arguments contain an access token. Never log the command or a CalledProcessError.
    return subprocess.Popen(command, cwd=directory, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
