import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QUrl
from news import NEWS_URL, NewsPanel, open_web_link

app = QApplication.instance() or QApplication([])
HOST = Path(__file__).resolve().parent / 'browser/bin/BrowserHost.exe'


class NavigationTests(unittest.TestCase):
    def decision(self, url, user=True, redirect=False):
        return subprocess.run([str(HOST), '--navigation-policy', url, str(user).lower(), str(redirect).lower()],
            check=True, capture_output=True, text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()

    def test_blog_posts_and_fragments_stay_embedded(self):
        for url in (NEWS_URL, NEWS_URL + '#updates', NEWS_URL + 'post/123/example', NEWS_URL + 'page/2'):
            with self.subTest(url=url): self.assertEqual(self.decision(url), 'allow')

    def test_lookalike_and_insecure_blog_do_not_stay_embedded(self):
        for url in ('https://mcretroupdates.tumblr.com.evil.test/', 'http://mcretroupdates.tumblr.com/', 'https://mcretroupdates.tumblr.com:8888/'):
            with self.subTest(url=url): self.assertEqual(self.decision(url), 'external')

    def test_user_click_can_open_web_link(self):
        self.assertEqual(self.decision('https://www.minecraft.net/'), 'external')

    def test_scripts_and_redirects_do_not_open_external_browser(self):
        self.assertEqual(self.decision('https://www.minecraft.net/', user=False), 'block')
        self.assertEqual(self.decision('https://www.minecraft.net/', redirect=True), 'block')

    def test_local_files_shell_urls_and_credentials_are_blocked(self):
        for url in ('file:///C:/private.txt', 'javascript:alert(1)', 'ms-settings:', 'data:text/html,test', 'https://user@mcretroupdates.tumblr.com/'):
            with self.subTest(url=url): self.assertEqual(self.decision(url), 'block')
        with patch('news.QDesktopServices.openUrl') as opened:
            for url in ('file:///C:/private.txt', 'ms-settings:', 'javascript:alert(1)', 'https://user@example.com/'):
                open_web_link(url)
            opened.assert_not_called()
            open_web_link('https://www.minecraft.net/')
            opened.assert_called_once_with(QUrl('https://www.minecraft.net/'))


class BrowserStateTests(unittest.TestCase):
    def setUp(self): self.panel = NewsPanel(load=False)
    def tearDown(self): self.panel.shutdown()

    def test_missing_runtime_shows_install_link(self):
        self.panel.handle_message({'event': 'missing-runtime'})
        self.assertFalse(self.panel.last_load_ok)
        self.assertIn('einmalig installieren', self.panel.message.text())

    def test_process_failure_is_recoverable_without_closing_launcher(self):
        self.panel.loaded(True)
        self.panel.process_finished(1)
        self.assertFalse(self.panel.last_load_ok)
        self.assertFalse(self.panel._started)
        self.assertFalse(self.panel._closed)

    def test_closed_panel_ignores_late_messages(self):
        self.panel.shutdown()
        self.panel.handle_message({'event': 'loaded', 'success': True})
        self.assertIsNone(self.panel.last_load_ok)

    def test_offline_preview_does_not_start_browser(self):
        self.assertFalse(self.panel._started)
        results = []
        self.panel.capture(results.append)
        self.assertEqual(results, [None])


if __name__ == '__main__': unittest.main()
